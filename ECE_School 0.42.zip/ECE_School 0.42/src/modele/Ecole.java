/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import java.util.*;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;

/**
 *
 * @author ramzi
 */
public class Ecole {
    private int id;
    private String nom; 
    private ArrayList<String> disciplines;
    private ArrayList<Classe> classes;
    private ArrayList<Enseignant> profs;
    private ArrayList<Eleve> eleves;
    private ArrayList<String> niveau;

    
    
    public Ecole(){
        
    }
    
    public Ecole(int id, String nom){
        this.nom = nom;
        this.id = id;
        disciplines = new ArrayList<>();
        classes = new ArrayList<>();
        profs = new ArrayList<>();
        eleves = new ArrayList<>();
        niveau = new ArrayList<>();
    }

    public ArrayList<String> getNiveau() {
        return niveau;
    }

    public void setNiveau(ArrayList<String> niveau) {
        this.niveau = niveau;
    }

    
    public ArrayList<Enseignant> getProfs() {
        return profs;
    }

    public void setProfs(ArrayList<Enseignant> profs) {
        this.profs = profs;
    }

    public ArrayList<Eleve> getEleves() {
        return eleves;
    }

    public void setEleves(ArrayList<Eleve> eleves) {
        this.eleves = eleves;
    }
    
    public DefaultPieDataset creerDataset(){
       
        Classe c = new Classe() ;
        DefaultPieDataset dataset = new DefaultPieDataset();
        
    for(int i = 0 ; i <  classes.size() ; i++)
    {
        c = classes.get(i) ;
        String nom = "classe " + c.getNom(); 
        
        dataset.setValue(nom , c.getEleves().size());
    }
    return dataset ; 
    }
    
    public void afficherCamembert(){
        
        DefaultPieDataset dataset = creerDataset() ;

        JFreeChart chart = ChartFactory.createPieChart("Nb d'éleves par classe",dataset,true, true, false );
// create and display a frame...
       ChartFrame frame = new ChartFrame("Diagramme", chart);
       frame.pack();
       frame.setVisible(true);
    }
 
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ArrayList<Classe> getClasses() {
        return classes;
    }

    public void setClasses(ArrayList<Classe> classes) {
        this.classes = classes;
    }
    
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public ArrayList<String> getDisciplines() {
        return disciplines;
    }

    public void setDisciplines(ArrayList<String> disciplines) {
        this.disciplines = disciplines;
    }
    
    public void ajoutDiscipline(String discipline){
        disciplines.add(discipline);
    }
    
    public void ajoutClasse(Classe c){
        classes.add(c);
    }
    
    public void retireDiscipline(String discipline){
        disciplines.remove(discipline);
    }
    
    public void afficheDisciplines(){
        for(int i=0; i<disciplines.size(); i++){
            System.out.println("Matiere "+(i+1)+" : "+disciplines.get(i));
        }
    }
    
    public void afficherClasse(){
        for(int i=0; i<classes.size(); i++){
            System.out.println("Classe n°"+(i+1)+" : "+classes.get(i).getNom());
        }
    }
    
    public void ajouterProf(Enseignant e){
        profs.add(e);
    }
    
    public void ajouterEleve(Eleve e){
        eleves.add(e);
    }
    
    public void ajouterNiveau(String niveau){
        this.niveau.add(niveau);
    }
    
    public void afficherProf(){
        System.out.println("Prof: ");
        for(int i=0; i<profs.size(); i++){
            System.out.println(i+". "+profs.get(i).getNom() +" "+profs.get(i).getPrenom());
        }
    }
    
    public void afficherEleve(){
        System.out.println("Eleve : ");
        for(int i=0; i<eleves.size(); i++){
            System.out.println(i+". "+eleves.get(i).getNom() +" "+eleves.get(i).getPrenom());
        }
    }
    
    public void afficherNiveau(){
        System.out.println("Les Niveaux disponibles dans l'école sont : ");
        for(int i=0; i<niveau.size(); i++){
            System.out.println(i+". "+niveau.get(i));
        }
    }
        
}
